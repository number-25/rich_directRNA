## `nf-core pipelines lint` overall result: Passed :white_check_mark: :warning:

Posted for pipeline commit 02d4b13

```diff
+| ✅  87 tests passed       |+
#| ❔  22 tests were ignored |#
!| ❗   4 tests had warnings |!
```

<details>

### :heavy_exclamation_mark: Test warnings:

* [readme](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/readme) - README did not have a Nextflow minimum version badge.
* [readme](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/readme) - README did not have an nf-core template version badge.
* [pipeline_name_conventions](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/pipeline_name_conventions) - Naming does not adhere to nf-core conventions: Contains uppercase letters
* [schema_lint](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/schema_lint) - Schema `$id` should be `https://raw.githubusercontent.com/number-25/LongTranscriptomics/main/nextflow_schema.json` or https://raw.githubusercontent.com/number-25/LongTranscriptomics/master/nextflow_schema.json. 
 Found `https://raw.githubusercontent.com/number-25/LongTranscriptomics/refs/heads/dev/nextflow_schema.json`

### :grey_question: Tests ignored:

* [files_exist](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/files_exist) - File is ignored: `CODE_OF_CONDUCT.md`
* [files_exist](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/files_exist) - File is ignored: `assets/nf-core-directrna_logo_light.png`
* [files_exist](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/files_exist) - File is ignored: `docs/images/nf-core-directrna_logo_light.png`
* [files_exist](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/files_exist) - File is ignored: `docs/images/nf-core-directrna_logo_dark.png`
* [files_exist](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/files_exist) - File is ignored: `.github/workflows/nf-test.yml`
* [files_exist](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/files_exist) - File is ignored: `.github/ISSUE_TEMPLATE/config.yml`
* [files_exist](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/files_exist) - File is ignored: `.github/workflows/awstest.yml`
* [files_exist](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/files_exist) - File is ignored: `nf-test.config`
* [files_exist](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/files_exist) - File is ignored: `.github/workflows/awsfulltest.yml`
* [files_exist](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/files_exist) - File is ignored: `ro-crate-metadata.json`
* [files_exist](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/files_exist) - File is ignored: `tests/nextflow.config`
* [files_exist](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/files_exist) - File is ignored: `nf-test.config`
* [files_exist](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/files_exist) - File is ignored: `.github/actions/get-shards/action.yml`
* [files_exist](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/files_exist) - File is ignored: `.github/actions/nf-test/action.yml`
* [files_exist](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/files_exist) - File is ignored: `tests/default.nf.test`
* [nextflow_config](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/nextflow_config) - nextflow_config
* [nf_test_content](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/nf_test_content) - nf_test_content
* [files_unchanged](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/files_unchanged) - Required pipeline config not found - {'manifest.contributors'}
* [actions_nf_test](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/actions_nf_test) - '.github/workflows/nf-test.yml' not found
* [actions_awstest](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/actions_awstest) - 'awstest.yml' workflow not found: `/mnt/hdd1/MedGen_directRNA/nextflow/LongTranscriptomics/.github/workflows/awstest.yml`
* [plugin_includes](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/plugin_includes) - plugin_includes
* [rocrate_readme_sync](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/rocrate_readme_sync) - `ro-crate-metadata.json` not found

### :white_check_mark: Tests passed:

* [files_exist](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/files_exist) - File found: `.gitattributes`
* [files_exist](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/files_exist) - File found: `.gitignore`
* [files_exist](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/files_exist) - File found: `.nf-core.yml`
* [files_exist](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/files_exist) - File found: `.prettierignore`
* [files_exist](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/files_exist) - File found: `.prettierrc.yml`
* [files_exist](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/files_exist) - File found: `CHANGELOG.md`
* [files_exist](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/files_exist) - File found: `CITATIONS.md`
* [files_exist](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/files_exist) - File found: `LICENSE` or `LICENSE.md` or `LICENCE` or `LICENCE.md`
* [files_exist](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/files_exist) - File found: `nextflow_schema.json`
* [files_exist](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/files_exist) - File found: `nextflow.config`
* [files_exist](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/files_exist) - File found: `README.md`
* [files_exist](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/files_exist) - File found: `.github/.dockstore.yml`
* [files_exist](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/files_exist) - File found: `.github/CONTRIBUTING.md`
* [files_exist](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/files_exist) - File found: `.github/ISSUE_TEMPLATE/bug_report.yml`
* [files_exist](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/files_exist) - File found: `.github/ISSUE_TEMPLATE/feature_request.yml`
* [files_exist](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/files_exist) - File found: `.github/PULL_REQUEST_TEMPLATE.md`
* [files_exist](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/files_exist) - File found: `.github/workflows/branch.yml`
* [files_exist](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/files_exist) - File found: `.github/workflows/linting_comment.yml`
* [files_exist](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/files_exist) - File found: `.github/workflows/linting.yml`
* [files_exist](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/files_exist) - File found: `assets/email_template.html`
* [files_exist](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/files_exist) - File found: `assets/email_template.txt`
* [files_exist](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/files_exist) - File found: `assets/sendmail_template.txt`
* [files_exist](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/files_exist) - File found: `assets/nf-core-LongTranscriptomics_logo_light.png`
* [files_exist](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/files_exist) - File found: `conf/modules.config`
* [files_exist](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/files_exist) - File found: `conf/test.config`
* [files_exist](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/files_exist) - File found: `conf/test_full.config`
* [files_exist](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/files_exist) - File found: `docs/images/nf-core-LongTranscriptomics_logo_light.png`
* [files_exist](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/files_exist) - File found: `docs/images/nf-core-LongTranscriptomics_logo_dark.png`
* [files_exist](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/files_exist) - File found: `docs/output.md`
* [files_exist](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/files_exist) - File found: `docs/README.md`
* [files_exist](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/files_exist) - File found: `docs/README.md`
* [files_exist](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/files_exist) - File found: `docs/usage.md`
* [files_exist](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/files_exist) - File found: `main.nf`
* [files_exist](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/files_exist) - File found: `assets/multiqc_config.yml`
* [files_exist](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/files_exist) - File found: `conf/base.config`
* [files_exist](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/files_exist) - File found: `conf/igenomes.config`
* [files_exist](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/files_exist) - File found: `conf/igenomes_ignored.config`
* [files_exist](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/files_exist) - File found: `modules.json`
* [files_exist](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/files_exist) - File not found check: `.github/ISSUE_TEMPLATE/bug_report.md`
* [files_exist](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/files_exist) - File not found check: `.github/ISSUE_TEMPLATE/feature_request.md`
* [files_exist](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/files_exist) - File not found check: `.github/workflows/push_dockerhub.yml`
* [files_exist](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/files_exist) - File not found check: `.markdownlint.yml`
* [files_exist](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/files_exist) - File not found check: `.nf-core.yaml`
* [files_exist](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/files_exist) - File not found check: `.yamllint.yml`
* [files_exist](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/files_exist) - File not found check: `bin/markdown_to_html.r`
* [files_exist](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/files_exist) - File not found check: `conf/aws.config`
* [files_exist](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/files_exist) - File not found check: `docs/images/nf-core-LongTranscriptomics_logo.png`
* [files_exist](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/files_exist) - File not found check: `lib/Checks.groovy`
* [files_exist](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/files_exist) - File not found check: `lib/Completion.groovy`
* [files_exist](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/files_exist) - File not found check: `lib/NfcoreTemplate.groovy`
* [files_exist](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/files_exist) - File not found check: `lib/Utils.groovy`
* [files_exist](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/files_exist) - File not found check: `lib/Workflow.groovy`
* [files_exist](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/files_exist) - File not found check: `lib/WorkflowMain.groovy`
* [files_exist](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/files_exist) - File not found check: `lib/WorkflowLongTranscriptomics.groovy`
* [files_exist](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/files_exist) - File not found check: `parameters.settings.json`
* [files_exist](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/files_exist) - File not found check: `pipeline_template.yml`
* [files_exist](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/files_exist) - File not found check: `Singularity`
* [files_exist](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/files_exist) - File not found check: `lib/nfcore_external_java_deps.jar`
* [files_exist](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/files_exist) - File not found check: `.travis.yml`
* [readme](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/readme) - README Zenodo placeholder was replaced with DOI.
* [pipeline_todos](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/pipeline_todos) - No TODO strings found
* [pipeline_if_empty_null](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/pipeline_if_empty_null) - No `ifEmpty(null)` strings found
* [template_strings](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/template_strings) - Did not find any Jinja template strings (0 files)
* [schema_lint](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/schema_lint) - Schema lint passed
* [schema_lint](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/schema_lint) - Input mimetype lint passed: 'text/csv'
* [schema_params](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/schema_params) - Schema matched params returned from nextflow config
* [system_exit](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/system_exit) - No `System.exit` calls found
* [actions_schema_validation](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/actions_schema_validation) - Workflow validation passed: branch.yml
* [actions_schema_validation](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/actions_schema_validation) - Workflow validation passed: ci.yml
* [actions_schema_validation](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/actions_schema_validation) - Workflow validation passed: fix-linting.yml
* [actions_schema_validation](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/actions_schema_validation) - Workflow validation passed: linting.yml
* [actions_schema_validation](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/actions_schema_validation) - Workflow validation passed: linting_comment.yml
* [merge_markers](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/merge_markers) - No merge markers found in pipeline files
* [modules_json](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/modules_json) - Only installed modules found in `modules.json`
* [multiqc_config](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/multiqc_config) - `assets/multiqc_config.yml` found and not ignored.
* [multiqc_config](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/multiqc_config) - `assets/multiqc_config.yml` contains `report_section_order`
* [multiqc_config](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/multiqc_config) - `assets/multiqc_config.yml` contains `export_plots`
* [multiqc_config](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/multiqc_config) - `assets/multiqc_config.yml` contains `report_comment`
* [multiqc_config](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/multiqc_config) - `assets/multiqc_config.yml` follows the ordering scheme of the minimally required plugins.
* [multiqc_config](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/multiqc_config) - `assets/multiqc_config.yml` contains 'export_plots: true'.
* [modules_structure](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/modules_structure) - modules directory structure is correct 'modules/nf-core/TOOL/SUBTOOL'
* [local_component_structure](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/local_component_structure) - local subworkflows directory structure is correct 'subworkflows/local/TOOL/SUBTOOL'
* [base_config](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/base_config) - `conf/base.config` found and not ignored.
* [modules_config](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/modules_config) - `conf/modules.config` found and not ignored.
* [modules_config](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/modules_config) - `MULTIQC` found in `conf/modules.config` and Nextflow scripts.
* [nfcore_yml](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/nfcore_yml) - Repository type in `.nf-core.yml` is valid: `pipeline`
* [nfcore_yml](https://nf-co.re/tools/docs/3.3.2/pipeline_lint_tests/nfcore_yml) - nf-core version in `.nf-core.yml` is set to the latest version: `3.3.2`

### Run details

* nf-core/tools version 3.3.2
* Run at `2025-11-17 05:54:14`

</details>
